# Homework 4 - Robby Lawrence
This README is for two files: greedy_coloring.cpp and shortest_paths.cpp.
The former can be compiled and ran with `g++ -std=c++11 greedy_coloring.cpp -o greedy_coloring && ./greedy_coloring <file_name>`.
The latter can be compiled and ran with `g++ -std=c++11 shortest_paths.cpp -o shortest_paths && ./shortest_paths <file_name`.
I've also included a test file with 1000 vertices and a density of 0.75, testing.dim, if you'd like to use it.
