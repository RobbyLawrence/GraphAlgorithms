To invoke the program, compile with the makefile provided and run ./dimacs <file_name>.
The program will output the adjacency matrix of the DIMACS file provided.
