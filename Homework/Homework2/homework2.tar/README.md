Robby Lawrence - Homework 2
Compile with g++ -std=c++11 components.cpp -o components. Usage is ./components <file_name>.
The program will output the number of components to stdout.
